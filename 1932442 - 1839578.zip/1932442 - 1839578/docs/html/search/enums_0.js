var searchData=
[
  ['definetypeofresource_394',['defineTypeOfResource',['../classresources_manager_class.html#a05a663b07abefdee05a1034b874643d3',1,'resourcesManagerClass']]]
];
