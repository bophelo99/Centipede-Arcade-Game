var searchData=
[
  ['logiclayerclass_207',['logicLayerClass',['../classlogic_layer_class.html',1,'']]]
];
